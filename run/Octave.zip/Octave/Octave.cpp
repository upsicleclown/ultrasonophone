#include "Octave.h"
a = 1.059;
f = 261.63;
Octave::(int id){
    _id = id;
    for(int j = 0; i< 12; i++){
        notes[j] = 1000000/c4;
        c4*=a;
    }
}

int Octave:: getNote(int j){
    return notes[j]
}
